import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HelpMenuComponent } from './help-menu/help-menu.component';
import {HelpHeadingComponent} from './help-heading/help-heading.component';

const routes: Routes = [{path: 'menu', component: HelpMenuComponent},{path:'heading',component:HelpHeadingComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
