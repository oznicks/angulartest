import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HelpHeadingComponent } from './help-heading/help-heading.component';
import { HelpMenuComponent } from './help-menu/help-menu.component';
import { HttpClientModule } from '@angular/common/http';
import { HelpItemComponent } from './help-item/help-item.component';

@NgModule({
  declarations: [
    AppComponent,
    HelpHeadingComponent,
    HelpMenuComponent,
    HelpItemComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
