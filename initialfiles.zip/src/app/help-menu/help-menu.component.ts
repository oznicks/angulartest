import { Component, OnInit } from '@angular/core';
import {HelpItems} from './help-menu-items';
import {HelpItem} from './help-menu-item';
import {HelpItemComponent} from '../help-item/help-item.component'



@Component({
  selector: 'app-help-menu',
  templateUrl: './help-menu.component.html',
  styleUrls: ['./help-menu.component.scss']
})
export class HelpMenuComponent implements OnInit {

  helpitems = HelpItems;
  selectedItem: HelpItem;
  constructor() { }

  ngOnInit() {
    console.log(this.helpitems)
  }
  menuItemClick(item){
    this.selectedItem = item;
    console.log(this.selectedItem);
  };

}
