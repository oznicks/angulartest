import {HelpItemStep} from './help-item-step';

export class HelpItem{
    name:string;
    icon_url:string;
    steps:Array<HelpItemStep>;
}