import {HelpItem} from './help-menu-item';
import {HelpItemStep} from './help-item-step';

export const HelpItems: HelpItem[] = [
    {
        name:"Search",
        icon_url:"",
        steps:[
            {"message":"Open the scrollout toolbar.","image":""},
            {"message":"Tap on the Query tool.","image":"<image of query toolbar button here>"},
            {"message":"Tap on the Query tool.","image":"<image of query toolbar button here>"},
        ]
    },
    {
        name:"Measure",
        icon_url:"",
        steps:[]
    },
    {
        name:"Draw",
        icon_url:"",
        steps:[]
    },
    {
        name:"TDist Tool",
        icon_url:"",
        steps:[]
    }
]
