import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HelpHeadingComponent } from './help-heading.component';

describe('HelpHeadingComponent', () => {
  let component: HelpHeadingComponent;
  let fixture: ComponentFixture<HelpHeadingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HelpHeadingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HelpHeadingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
