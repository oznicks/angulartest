import { Component, OnInit, Input } from '@angular/core';
import {HelpItem} from '../help-menu/help-menu-item';

@Component({
  selector: 'app-help-item',
  templateUrl: './help-item.component.html',
  styleUrls: ['./help-item.component.scss']
})
export class HelpItemComponent implements OnInit {
  @Input() item_: HelpItem;
  constructor() { }

  ngOnInit() {
  }

}
