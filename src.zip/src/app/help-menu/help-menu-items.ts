import {HelpItem} from './help-menu-item';

export const HelpItems: HelpItem[] = [
    {
        name:"Search",
        icon_url:"",
        activities:[
            {
                name:"Query Tool",image:"No image",steps:[
                {message:"Open tool",image:"No image"},
                {message:"Close tool",image:"Close tool"}
            ]
        },
        {
            name:"Lot/Plan Search",image:"No image",steps:[
            {message:"Open tool",image:"No image"},
            {message:"Close tool",image:"Close tool"}
        ]
    }
        ]
    },
    {
        name:"Testing",
        icon_url:"",
        activities:[]
    },
    {
        name:"Searching",
        icon_url:"",
        activities:[]
    },
    {
        name:"Searches",
        icon_url:"",
        activities:[]
    }
    
]
