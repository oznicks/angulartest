export class HelpItemStep{
    message:string;
    image:string;
}