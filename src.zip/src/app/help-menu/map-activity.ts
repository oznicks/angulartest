import {HelpItemStep} from './help-item-step';

export class MapActivity {
    name: string;
    image: string;
    steps:Array<HelpItemStep>;
}