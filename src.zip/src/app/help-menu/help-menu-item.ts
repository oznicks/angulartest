import {MapActivity} from './map-activity';

export class HelpItem{
    name:string;
    icon_url:string;
    activities:Array<MapActivity>;
}